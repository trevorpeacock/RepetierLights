host = 'localhost'
port = 3344
printer = ''
apikey = ''
serial_port = ''
serial_port_baud = 9600
